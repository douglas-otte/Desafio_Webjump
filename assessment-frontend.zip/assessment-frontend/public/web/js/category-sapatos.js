const productsGrid = document.querySelector('.products-grid');
const filterButtons = document.querySelectorAll('.filter-btn');

// Função para renderizar os produtos no grid
function renderProducts(products) {
  productsGrid.innerHTML = '';
  products.forEach(product => {
    const productCard = document.createElement('div');
    productCard.classList.add('product');

    productCard.innerHTML = `
      <img src="${product.image}" alt="${product.name}" class="product-image">
      <div class="name-product">${product.name}</div>
    `;

    const productInfoElement = document.createElement('div');
    productInfoElement.classList.add('price-box');

    const productSpecialPrice = document.createElement("p");
    if (product.specialPrice !== undefined) {
    productSpecialPrice.textContent = "R$" + product.specialPrice.toFixed(2);
    }
    productSpecialPrice.classList.add("old-price");
    productInfoElement.appendChild(productSpecialPrice);

    const productPrice = document.createElement("p");
    if (product.price !== undefined) {
    productPrice.textContent = "R$" + product.price.toFixed(2);
    }
    productPrice.classList.add("price");
    productInfoElement.appendChild(productPrice);

    const buyButton = document.createElement("button");
    buyButton.textContent = "Comprar";
    buyButton.classList.add("action");
    buyButton.classList.add("secondary");
    
    productCard.appendChild(productInfoElement);
    productCard.appendChild(buyButton);

    productsGrid.appendChild(productCard);
  });
}

// Função para mostrar ou ocultar o botão de limpar filtros
function toggleClearFiltersButton(visible) {
  const clearFiltersButton = document.getElementById('clear-filters');
  clearFiltersButton.style.display = visible ? 'block' : 'none';
}

// Função para filtrar produtos por cor
function filterProductsByColor(color, products) {
  if (color === 'Todas') {
    renderProducts(products.items);
  } else {
    const filteredProducts = products.items.filter(product => product.filter[0].color === color);
    renderProducts(filteredProducts);
  }
  toggleClearFiltersButton(true);
}

// Função para limpar todos os filtros e mostrar todos os produtos
function clearFilters(products) {
  renderProducts(products.items);
  toggleClearFiltersButton(false);
}

// Função para fazer a requisição à API e obter os dados
async function fetchData() {
  try {
    const response = await fetch('http://localhost:8888/api/V1/categories/3');
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Erro ao buscar dados da API:', error);
  }
}

// Função para ordenar os produtos
function sortProducts(option, products) {
  if (option === 'price') {
    products.items.sort((a, b) => a.price - b.price);
  } else if (option === 'name') {
    products.items.sort((a, b) => a.name.localeCompare(b.name));
  }
  renderProducts(products.items);
}

// Função para iniciar o aplicativo
async function startApp() {
  const products = await fetchData();

  // Adicionar eventos de clique aos botões de filtro
  filterButtons.forEach(button => {
    button.addEventListener('click', () => {
      const selectedColor = button.getAttribute('data-color');
      filterProductsByColor(selectedColor, products);
    });
  });

  // Adicionar evento de mudança para o seletor de ordenação
  const sortSelect = document.getElementById('sort');
  sortSelect.addEventListener('change', () => {
    const selectedOption = sortSelect.value;
    sortProducts(selectedOption, products);
  });

  // Adicionar evento de clique para o botão de limpar filtros
  const clearFiltersButton = document.getElementById('clear-filters');
  clearFiltersButton.addEventListener('click', () => {
    clearFilters(products);
  });

  // Renderizar todos os produtos
  renderProducts(products.items);
}

// Iniciar o aplicativo
startApp();

// Grid e lista de produtos
$(function(){
  $('.icon-grid').click(function(i){
    $('#product-grid').addClass('grid');
    $(this).toggleClass('active');
  });
  $('.icon-list').click(function(i){
    $('#product-grid').removeClass('grid');
    $(this).toggleClass('active');
  });

});