$(document).ready(function() {

    // criando categorias através do endpoint
    let categoriasMenu = document.getElementById('categorias-menu');

    fetch('http://localhost:8888/api/V1/categories/list')
        .then(response => {
        if (!response.ok) {
            throw new Error('Erro ao obter os dados das categorias');
        }
        return response.json();
    })
    .then(data => {
      let items = data.items; // Acessando a propriedade "items" dos dados

      items.forEach(categoria => {
        let li = document.createElement('li'); // Criando a tag <li>
        let link = document.createElement('a'); // Criando a tag <a>
        link.textContent = categoria.name; // Usando a propriedade "name" da categoria
        link.href = `${categoria.path}`; // Definindo o atributo href
        li.appendChild(link);
        categoriasMenu.appendChild(li);
      });
    })
    .catch(error => {
      console.error('Ocorreu um erro:', error);
    });

    // MENU MOBILE
    $('.menu-mobile').click(() => {
        $('.menu-header').addClass('collapsed');
        $('.close-menu').addClass('active');
        $('.menu-header').css("marginLeft", "0");
        $('.menu-header').css("display", "block");
    });

    $(".close-menu").on("click", function(){
        $(".menu-header").removeClass("collapsed");
        $('.close-menu').removeClass('active');
        $('.menu-header').css("marginLeft", "-500px");
    });   
});